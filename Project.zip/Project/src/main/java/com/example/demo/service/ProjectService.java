package com.example.demo.service;
import com.example.demo.model.ProjectModel;

public interface ProjectService {
	public ProjectModel CreateUser(ProjectModel proj);
	
		
}




